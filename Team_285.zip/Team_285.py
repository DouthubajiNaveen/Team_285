import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
from PIL import Image, ImageTk
import webbrowser

class CareerCounsellingSystemGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("National Career Guidance Program")
        self.root.geometry("1000x700")
        self.root.configure(bg="#f0f8ff")
        
        # Load career database
        self.load_career_data()
        
        # Create GUI elements
        self.create_header()
        self.create_main_frame()
        
    def load_career_data(self):
        """Load the career database"""
        self.career_db = pd.DataFrame({
            'Career': ['Software Engineer', 'Doctor', 'Graphic Designer', 'Civil Engineer', 
                      'Teacher', 'Data Scientist', 'Architect', 'Marketing Manager',
                      'Entrepreneur', 'Psychologist', 'AI Specialist', 'Environmental Scientist'],
            
            'Skills': ['programming algorithms problem-solving', 
                      'biology medicine patient-care diagnosis',
                      'creativity art design illustration',
                      'math physics construction design',
                      'communication patience teaching mentoring',
                      'statistics programming machine-learning data-analysis',
                      'design creativity construction planning',
                      'communication creativity market-analysis strategy',
                      'leadership risk-taking business-management',
                      'counseling listening human-behavior analysis',
                      'programming math neural-networks research',
                      'biology chemistry environmental-policy analysis'],
            
            'Interests': ['technology computers problem-solving',
                         'biology helping-people healthcare',
                         'art creativity visual-communication',
                         'construction design infrastructure',
                         'education mentoring community',
                         'data analysis technology research',
                         'design buildings creativity',
                         'business trends consumer-behavior',
                         'innovation startups problem-solving',
                         'human-mind behavior helping-people',
                         'technology future machine-intelligence',
                         'nature sustainability problem-solving'],
            
            'Education': ['B.Tech/B.E. in Computer Science (4 years)',
                         'MBBS (5.5 years) + Specialization (3-5 years)',
                         'Bachelor of Design (4 years)',
                         'B.Tech in Civil Engineering (4 years)',
                         'B.Ed (2 years) + Bachelor Degree (3 years)',
                         'B.Tech/B.Sc in Data Science (4 years)',
                         'B.Arch (5 years)',
                         'MBA (2 years) + Bachelor Degree (3 years)',
                         'Varied (Business courses helpful)',
                         'MA/M.Sc in Psychology (2 years) + Bachelor (3 years)',
                         'B.Tech/M.Tech in AI/ML (4-6 years)',
                         'M.Sc in Environmental Science (2 years) + Bachelor (3 years)'],
            
            'Dropout_Risk': ['Medium - Continuous learning required',
                           'High - Long training period',
                           'High - Competitive field',
                           'Medium - Physically demanding',
                           'Medium - Lower initial pay',
                           'Medium - Rapidly evolving field',
                           'High - Long education period',
                           'Medium - Performance pressure',
                           'Very High - Uncertain success',
                           'Medium - Emotional demands',
                           'Medium - Fast-changing technology',
                           'Medium - Niche field']
        })
        
        # Combine features for recommendation
        self.career_db['Combined'] = self.career_db['Skills'] + ' ' + self.career_db['Interests']
        self.vectorizer = TfidfVectorizer(stop_words='english')
        self.tfidf_matrix = self.vectorizer.fit_transform(self.career_db['Combined'])
    
    def create_header(self):
        """Create the header section"""
        header_frame = tk.Frame(self.root, bg="#1e3f66", height=100)
        header_frame.pack(fill="x")
        
        # Logo and title
        try:
            # This is a placeholder for logo - you would replace with actual image file
            logo_img = Image.new('RGB', (80, 80), color="#1e3f66")
            logo_img = ImageTk.PhotoImage(logo_img)
            logo_label = tk.Label(header_frame, image=logo_img, bg="#1e3f66")
            logo_label.image = logo_img
            logo_label.pack(side="left", padx=10)
        except:
            pass
        
        title_label = tk.Label(header_frame, text="NATIONAL CAREER GUIDANCE PROGRAM", 
                              font=("Helvetica", 16, "bold"), fg="white", bg="#1e3f66")
        title_label.pack(side="left", pady=20)
        
        subtitle_label = tk.Label(header_frame, text="Aligned with NEP 2020 Guidelines", 
                                 font=("Helvetica", 10), fg="white", bg="#1e3f66")
        subtitle_label.pack(side="left", pady=20)
    
    def create_main_frame(self):
        """Create the main content frame"""
        self.main_frame = tk.Frame(self.root, bg="#f0f8ff")
        self.main_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Welcome message
        welcome_label = tk.Label(self.main_frame, 
                                text="Welcome to the National Career Guidance Program\nFind your ideal career path based on your skills and interests",
                                font=("Helvetica", 12), bg="#f0f8ff", fg="#333")
        welcome_label.pack(pady=(0, 20))
        
        # Create notebook for different sections
        self.notebook = ttk.Notebook(self.main_frame)
        self.notebook.pack(fill="both", expand=True)
        
        # Create tabs
        self.create_recommendation_tab()
        self.create_explore_tab()
        self.create_about_tab()
    
    def create_recommendation_tab(self):
        """Create the career recommendation tab"""
        tab = tk.Frame(self.notebook, bg="#f0f8ff")
        self.notebook.add(tab, text="Career Recommendations")
        
        # Input frame
        input_frame = tk.Frame(tab, bg="#f0f8ff")
        input_frame.pack(pady=10, fill="x")
        
        tk.Label(input_frame, text="Enter your skills/interests:", 
                font=("Helvetica", 10), bg="#f0f8ff").pack(anchor="w")
        
        self.interest_entry = tk.Entry(input_frame, width=50, font=("Helvetica", 10))
        self.interest_entry.pack(pady=5, fill="x")
        
        example_label = tk.Label(input_frame, 
                               text="Example: programming problem-solving technology", 
                               font=("Helvetica", 8), fg="gray", bg="#f0f8ff")
        example_label.pack(anchor="w")
        
        tk.Button(input_frame, text="Get Recommendations", command=self.show_recommendations,
                 bg="#4a90e2", fg="white", relief="flat", padx=15, pady=5).pack(pady=10)
        
        # Results frame
        self.results_frame = tk.Frame(tab, bg="#f0f8ff")
        self.results_frame.pack(fill="both", expand=True)
        
    def create_explore_tab(self):
        """Create the explore careers tab"""
        tab = tk.Frame(self.notebook, bg="#f0f8ff")
        self.notebook.add(tab, text="Explore Careers")
        
        # Career selection
        tk.Label(tab, text="Select a career to explore:", 
                font=("Helvetica", 10), bg="#f0f8ff").pack(anchor="w", pady=(10, 0))
        
        self.career_combobox = ttk.Combobox(tab, values=list(self.career_db['Career']), 
                                           font=("Helvetica", 10))
        self.career_combobox.pack(pady=5, fill="x")
        self.career_combobox.bind("<<ComboboxSelected>>", self.display_career_details)
        
        # Career details display
        self.career_details_text = scrolledtext.ScrolledText(tab, wrap=tk.WORD, 
                                                           width=80, height=20,
                                                           font=("Helvetica", 10))
        self.career_details_text.pack(fill="both", expand=True, pady=10)
        
    def create_about_tab(self):
        """Create the about/help tab"""
        tab = tk.Frame(self.notebook, bg="#f0f8ff")
        self.notebook.add(tab, text="About & Help")
        
        about_text = """
        National Career Guidance Program
        
        This program helps students and professionals identify suitable career paths 
        based on their skills and interests, aligned with the National Education Policy (NEP) 2020.
        
        Features:
        - Personalized career recommendations
        - Detailed career information
        - Education pathway guidance
        - Dropout risk assessment
        
        How to use:
        1. Enter your skills and interests in the "Career Recommendations" tab
        2. View suggested career options
        3. Explore detailed information about any career
        4. Make informed decisions about your future
        
        For more information about NEP 2020, visit the official website.
        """
        
        about_label = tk.Label(tab, text=about_text, font=("Helvetica", 10), 
                             bg="#f0f8ff", justify="left")
        about_label.pack(pady=20, padx=20, anchor="w")
        
        # Add a link to NEP 2020
        nep_link = tk.Label(tab, text="Learn more about NEP 2020", 
                          font=("Helvetica", 10, "underline"), 
                          fg="blue", cursor="hand2", bg="#f0f8ff")
        nep_link.pack(pady=10)
        nep_link.bind("<Button-1>", lambda e: webbrowser.open("https://www.education.gov.in/en/nep"))
    
    def recommend_careers(self, user_interests, top_n=5):
        """Recommend careers based on user interests"""
        user_tfidf = self.vectorizer.transform([user_interests])
        cosine_sim = cosine_similarity(user_tfidf, self.tfidf_matrix)
        sim_scores = list(enumerate(cosine_sim[0]))
        sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)
        return self.career_db.iloc[[i[0] for i in sim_scores[:top_n]]]
    
    def show_recommendations(self):
        """Display career recommendations"""
        interests = self.interest_entry.get()
        if not interests:
            messagebox.showwarning("Input Required", "Please enter your skills/interests")
            return
        
        try:
            recommendations = self.recommend_careers(interests)
            
            # Clear previous results
            for widget in self.results_frame.winfo_children():
                widget.destroy()
            
            # Create a treeview to display results
            tree = ttk.Treeview(self.results_frame, columns=("Career", "Education"), 
                              show="headings", height=min(10, len(recommendations)))
            
            # Style the treeview
            style = ttk.Style()
            style.configure("Treeview.Heading", font=("Helvetica", 10, "bold"))
            style.configure("Treeview", font=("Helvetica", 9), rowheight=25)
            
            tree.heading("Career", text="Career")
            tree.heading("Education", text="Education Pathway")
            tree.column("Career", width=200)
            tree.column("Education", width=400)
            
            for idx, row in recommendations.iterrows():
                tree.insert("", "end", values=(row['Career'], row['Education']))
            
            tree.pack(fill="both", expand=True)
            
            # Add button to view details
            tk.Button(self.results_frame, text="View Selected Career Details", 
                     command=lambda: self.show_selected_career(tree), 
                     bg="#4a90e2", fg="white", relief="flat").pack(pady=10)
            
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")
    
    def show_selected_career(self, tree):
        """Show details of selected career from treeview"""
        selected_item = tree.focus()
        if not selected_item:
            messagebox.showwarning("Selection Required", "Please select a career from the list")
            return
        
        career_name = tree.item(selected_item)['values'][0]
        self.notebook.select(1)  # Switch to Explore tab
        self.career_combobox.set(career_name)
        self.display_career_details()
    
    def display_career_details(self, event=None):
        """Display comprehensive career information"""
        career_name = self.career_combobox.get()
        if not career_name:
            return
        
        try:
            career = self.career_db[self.career_db['Career'] == career_name].iloc[0]
            
            details = f"""
            {'='*50}
            CAREER PROFILE: {career_name.upper()}
            {'='*50}
            
            Required Skills: {career['Skills']}
            
            Matching Interests: {career['Interests']}
            
            Education Pathway: {career['Education']}
            
            Dropout Risk: {career['Dropout_Risk']}
            
            {'='*50}
            NEP 2020 Alignment:
            - Multidisciplinary approach available
            - Vocational training options
            - Multiple entry/exit points in education
            """
            
            self.career_details_text.config(state="normal")
            self.career_details_text.delete(1.0, tk.END)
            self.career_details_text.insert(tk.END, details)
            
            # Highlight risk level
            if 'High' in career['Dropout_Risk']:
                self.career_details_text.tag_add("warning", "6.0", "6.end")
                self.career_details_text.tag_config("warning", foreground="red")
            
            self.career_details_text.config(state="disabled")
            
        except IndexError:
            messagebox.showerror("Error", f"Career '{career_name}' not found in our database")

if __name__ == "__main__":
    root = tk.Tk()
    app = CareerCounsellingSystemGUI(root)
    root.mainloop()